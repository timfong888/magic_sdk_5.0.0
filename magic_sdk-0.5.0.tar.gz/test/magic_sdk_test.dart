import 'package:flutter_test/flutter_test.dart';

import 'package:magic_sdk/magic_sdk.dart';

void main() {}
