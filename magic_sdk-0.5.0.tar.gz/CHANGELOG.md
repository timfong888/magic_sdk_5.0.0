## 0.4.0

Supports LoginWithSMS

## 0.3.2

Fix build fail, due to web3dart signToSignature api breaking change

## 0.3.0

* Add support for Social Login

## 0.2.0

* Magic SDK supports web3dart
    * sendTransaction
    * getAccount
    * Contract

## 0.1.0

* Magic SDK Core release
