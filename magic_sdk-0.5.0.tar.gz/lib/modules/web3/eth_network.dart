/// Supported Eth Network
///
enum EthNetwork {
  mainnet,
  kovan,
  rinkeby,
  ropsten,
}
