/// Leave as placeholder
class BaseConfiguration {}
